.. _routines.help:

NumPy-specific help functions
=============================

.. currentmodule:: numpy

.. autosummary::
   :toctree: generated/

   info
