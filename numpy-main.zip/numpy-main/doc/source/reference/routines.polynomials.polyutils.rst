Polyutils
=========

.. automodule:: numpy.polynomial.polyutils
