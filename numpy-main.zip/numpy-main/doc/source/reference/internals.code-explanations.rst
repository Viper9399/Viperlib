:orphan:

*************************
NumPy C code explanations
*************************

.. This document has been moved to ../dev/internals.code-explanations.rst.

This document has been moved to :ref:`c-code-explanations`.