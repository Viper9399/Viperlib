
The "NumPy C Style Guide" at this page has been superseded by
"NEP 45 — C Style Guide" at https://numpy.org/neps/nep-0045-c_style_guide.html
